﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PNotas
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[,] respostas = new string[8,10];
            string[] gabarito = { "A", "E", "B", "A", "C", "A", "E", "D", "D", "C" };

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    respostas[i,j] = Interaction.InputBox("Digite a resposta da questão " + (j + 1) + " do aluno " + (i + 1) + ":", "Entrada das Respostas");

                    if ((respostas[i,j] == "A" || respostas[i,j] == "a") || 
                        (respostas[i,j] == "B" || respostas[i,j] == "b") ||
                        (respostas[i,j] == "C" || respostas[i,j] == "c") || 
                        (respostas[i,j] == "D" || respostas[i,j] == "d") || 
                        (respostas[i,j] == "E" || respostas[i,j] == "e"))
                    {
                        lbxResultado.Items.Add("O aluno: " + (i + 1) + ((String.Compare(respostas[i, j], gabarito[j], true) == 0) ? " acertou " : " errou ") + 
                            "a questão " + (j + 1) + ". Era " + gabarito[j] + ", escolheu " + respostas[i, j].ToUpper());
                    }
                    else
                    {
                        MessageBox.Show("Digite uma resposta válida!");
                        j--;
                    }
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lbxResultado.Items.Clear();
            btnVerificar.Focus();
        }
    }
}
