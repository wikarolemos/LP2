﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//para cada atributo, nós criamos uma propriedade
//quando a função estiver dentro da classe, ela é um método

namespace PTesteClasses
{
    abstract class Empregado
    {
        private int matricula; //atributo
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;
        private char homeOffice;

        public int Matricula //propriedade
        {
            get { return matricula; }
            set { matricula = value; }
        }

        public string NomeEmpregado //propriedade
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }

        public DateTime DataEntradaEmpresa //propriedade
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }

        public char HomeOffice //propriedade
        {
            get { return homeOffice; }
            set { homeOffice = value; }
        }

        public String VerificaHome() //método
        {
            if (homeOffice == 'S')
                return "Empregado trabalha em home office";
            else
                return "Empregado não trabalha em home office";
        }

        //"virtual" deixa criar uma nova versão de um método em uma subclasse
        public virtual int TempoTrabalho()
        {
            //representa um intervalo de tempo
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);

            return (span.Days);
        }

        //"abstract" é uma "obrigação" para criar a função em uma subclasse
        public abstract double SalarioBruto();
    }
}
