﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();//sair
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();//limpar
            txtRaio.Clear();
            txtVolume.Clear();

            txtRaio.Focus();//voltar o foco para o raio
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double raio, altura, volume;

            if (double.TryParse(txtAltura.Text, out altura) && double.TryParse(txtRaio.Text, out raio)) //verificar os valores
            {
                if ((altura <= 0) || (raio <= 0))
                {
                    MessageBox.Show("Altura e Raio devem ser maiores que zero");
                    txtRaio.Focus();
                }
                else
                {
                    //volume = PI * raio * raio * altura
                    volume = Math.PI * Math.Pow(raio, 2) * altura;
                    txtVolume.Text = volume.ToString("N2"); //transformar o double em string
                }
            }
            else
            {
                MessageBox.Show("Valores Inválidos");
                txtRaio.Focus();
            }
        }
    }
}
