﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class formCalculadora : Form
    {
        double primeiroNum, segundoNum, resultado;

        public formCalculadora()
        {
            InitializeComponent();
        }

        private void txtPrimeiroNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)13)
            {
                SendKeys.Send("{TAB}");

                e.Handled = true;
            }
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtPrimeiroNum.Text, out primeiroNum) && double.TryParse(txtSegundoNum.Text, out segundoNum))
            {
                resultado = primeiroNum * segundoNum;
                txtResultado.Text = resultado.ToString();
            }
            else
            {
                MessageBox.Show("Insira um número válido nos dois campos");

                txtPrimeiroNum.Clear();
                txtSegundoNum.Clear();
                txtResultado.Clear();

                txtPrimeiroNum.Focus();
            }
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtPrimeiroNum.Text, out primeiroNum) && double.TryParse(txtSegundoNum.Text, out segundoNum))
            {
                if(segundoNum != 0)
                {
                    resultado = primeiroNum / segundoNum;
                    txtResultado.Text = resultado.ToString();
                }
                else
                {
                    MessageBox.Show("Não existe divisão por zero");

                    txtSegundoNum.Clear();
                    txtResultado.Clear();

                    txtSegundoNum.Focus();
                }
            }
            else
            {
                MessageBox.Show("Insira um número válido nos dois campos");

                txtPrimeiroNum.Clear();
                txtSegundoNum.Clear();
                txtResultado.Clear();

                txtPrimeiroNum.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPrimeiroNum.Clear();
            txtSegundoNum.Clear();
            txtResultado.Clear();

            txtPrimeiroNum.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnAdicao_Click(object sender, EventArgs e)
        {
            if(double.TryParse(txtPrimeiroNum.Text, out primeiroNum) && double.TryParse(txtSegundoNum.Text, out segundoNum))
            {
                resultado = primeiroNum + segundoNum;
                txtResultado.Text = resultado.ToString();
            }
            else
            {
                MessageBox.Show("Insira um número válido nos dois campos");

                txtPrimeiroNum.Clear();
                txtSegundoNum.Clear();
                txtResultado.Clear();

                txtPrimeiroNum.Focus();
            }
        }
        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtPrimeiroNum.Text, out primeiroNum) && double.TryParse(txtSegundoNum.Text, out segundoNum))
            {
                resultado = primeiroNum - segundoNum;
                txtResultado.Text = resultado.ToString();
            }
            else
            {
                MessageBox.Show("Insira um número válido nos dois campos");

                txtPrimeiroNum.Clear();
                txtSegundoNum.Clear();
                txtResultado.Clear();

                txtPrimeiroNum.Focus();
            }
        }

    }
}
