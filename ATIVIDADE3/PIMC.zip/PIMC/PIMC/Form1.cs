﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class formIMC : Form
    {
        public formIMC()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double altura, peso, imc;

            if (double.TryParse(txtAltura.Text, out altura) && double.TryParse(txtPeso.Text, out peso))
            {
                imc = peso / Math.Pow(altura, 2);

                if (imc < 18.5)
                {
                    txtIMC.Text = imc.ToString("N1") + " | MAGREZA";
                }
                else if (imc >= 18.5 && imc <= 24.9)
                {
                    txtIMC.Text = imc.ToString("N1") + " | NORMAL";
                }
                else if (imc >= 25 && imc <= 29.9)
                {
                    txtIMC.Text = imc.ToString("N1") + " | SOBREPESO";
                }
                else if (imc >= 30 && imc <= 40)
                {
                    txtIMC.Text = imc.ToString("N1") + " | OBESIDADE";
                }
                else
                    txtIMC.Text = imc.ToString("N1") + " | OBESIDADE GRAVE";
            }
            else
            {
                MessageBox.Show("Insira um número válido nos campos");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtIMC.Clear();
        }
    }
}
