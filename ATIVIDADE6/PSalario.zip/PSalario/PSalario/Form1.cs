﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class formPSalario : Form
    {
        public formPSalario()
        {
            InitializeComponent();
        }

        private void btnDesconto_Click(object sender, EventArgs e)
        {
            double salarioBruto, salarioFamilia, salarioLiquido, descontoINSS, descontoIRPF, numFilhos;

            //VERIFICAR SE O TXT ESTÁ COM ALGUM NOME
            if (txtNome.Text != string.Empty)
            {
                //VERIFICAR SE O USUARIO DIGITOU UM SALARIO E QTD DE FILHOS VALIDA
                if (double.TryParse(mskbxSalarioBruto.Text, out salarioBruto) && double.TryParse(nudNumFilhos.Text, out numFilhos))
                {
                    //VERIFICAR SE SALARIO É MAIOR QUE 0
                    if (salarioBruto <= 0)
                    {
                        MessageBox.Show("Insira um salário maior que zero");

                        mskbxSalarioBruto.Clear();
                        mskbxSalarioBruto.Focus();
                    }
                    else
                    {
                        //DESCONTO INSS
                        if (salarioBruto <= 800.47)
                        {
                            txtAliquotaINSS.Text = "7,65%";
                            descontoINSS = 0.0765 * salarioBruto;
                            txtDescontoINSS.Text = descontoINSS.ToString("N2");
                        }
                        else if (salarioBruto <= 1050)
                        {
                            txtAliquotaINSS.Text = "8,65%";
                            descontoINSS = 0.0865 * salarioBruto;
                            txtDescontoINSS.Text = descontoINSS.ToString("N2");
                        }
                        else if (salarioBruto <= 1400.77)
                        {
                            txtAliquotaINSS.Text = "9,00%";
                            descontoINSS = 0.09 * salarioBruto;
                            txtDescontoINSS.Text = descontoINSS.ToString("N2");
                        }
                        else if (salarioBruto <= 2801.56)
                        {
                            txtAliquotaINSS.Text = "11,00%";
                            descontoINSS = 0.11 * salarioBruto;
                            txtDescontoINSS.Text = descontoINSS.ToString("N2");
                        }
                        else
                        {
                            txtAliquotaINSS.Text = "TETO INSS";
                            descontoINSS = 308.17;
                            txtDescontoINSS.Text = descontoINSS.ToString("N2");
                        }

                        //DESCONTO IRPF
                        if (salarioBruto <= 1257.12)
                        {
                            txtAliquotaIRPF.Text = "ISENTO";
                            descontoIRPF = 0;
                            txtDescontoIRPF.Text = descontoIRPF.ToString("N2");
                        }
                        else if (salarioBruto <= 2512.08)
                        {
                            txtAliquotaIRPF.Text = "15%";
                            descontoIRPF = 0.15 * salarioBruto;
                            txtDescontoIRPF.Text = descontoIRPF.ToString("N2");
                        }
                        else
                        {
                            txtAliquotaIRPF.Text = "27,5%";
                            descontoIRPF = 0.275 * salarioBruto;
                            txtDescontoIRPF.Text = descontoIRPF.ToString("N2");
                        }

                        //SALARIO FAMILIA
                        if (numFilhos > 0)
                        {
                            if (salarioBruto <= 435.52)
                            {
                                salarioFamilia = numFilhos * 22.33;
                                txtSalarioFamilia.Text = salarioFamilia.ToString("N2");
                            }
                            else if (salarioBruto <= 654.61)
                            {
                                salarioFamilia = numFilhos * 15.74;
                                txtSalarioFamilia.Text = salarioFamilia.ToString("N2");
                            }
                            else
                            {
                                salarioFamilia = 0;
                                txtSalarioFamilia.Text = salarioFamilia.ToString("N2");
                            }
                        }
                        else
                        {
                            salarioFamilia = 0;
                            txtSalarioFamilia.Text = salarioFamilia.ToString("N2");
                        }

                        //SALARIO LIQUIDO
                        salarioLiquido = (salarioBruto - (descontoINSS + descontoIRPF)) + salarioFamilia;
                        txtSalarioLiquido.Text = salarioLiquido.ToString("N2");

                        //EXIBIR DADOS
                        lblDados.Text = "Os descontos do salário" + (rbtnSexoFem.Checked == true ? " da Sra. " : " do Sr. ") + txtNome.Text + " que é " +
                            (cbxCasado.CheckState == CheckState.Checked ? (rbtnSexoFem.Checked == true ? "casada" : "casado") : (rbtnSexoFem.Checked == true ? "solteira" : "solteiro")) +
                            " e tem " + (numFilhos > 1 ? nudNumFilhos.Text + " filhos(as)" : nudNumFilhos.Text + " filho(a)");
                    }
                }
                else
                {
                    MessageBox.Show("Insira um salário válido");

                    mskbxSalarioBruto.Clear();
                    mskbxSalarioBruto.Focus();
                }
            }
            else
            {
                MessageBox.Show("Insira um nome");

                txtNome.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            mskbxSalarioBruto.Clear();
            nudNumFilhos.Text = "0";
            lblDados.ResetText();
            txtAliquotaINSS.Clear();
            txtAliquotaIRPF.Clear();
            txtAliquotaINSS.Clear();
            txtSalarioFamilia.Clear();
            txtSalarioLiquido.Clear();
            txtDescontoINSS.Clear();
            txtDescontoIRPF.Clear();
            cbxCasado.Checked = false;

            txtNome.Focus();
        }
    }
}
